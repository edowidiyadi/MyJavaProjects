/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inlämningsuppgift1;
import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author edo
 */
public class Nummer2 {
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);
        System.out.print("Mata in ett tecken: ");
        char tecken = (char)System.in.read();
        in.nextLine();
        System.out.print("Mata in sträng: ");
        String sträng = in.nextLine();
        System.out.println("Du mata in tecken \""+tecken+"\" och sträng \""+sträng+"\"");
        System.out.print("Nu blir det : ");
        change(sträng,tecken);
    }
    
    public static void change(String sträng,char tecken) {
        System.out.println("\""+tecken+sträng+"\"");
        
    }
}
